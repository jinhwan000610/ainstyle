import "./App.css";
import TagSection from "./components/TagSection";
import Header from "./components/Header";
import ItemSection from "./components/ItemSection";
import SelectSection from "./components/SelectSection";

function App() {
  return (
    <>
      <Header></Header>
      <SelectSection></SelectSection>
      <TagSection></TagSection>
      <ItemSection></ItemSection>
    </>
  );
}

export default App;
